# ODCPE BT Tether (standalone Flutter app)

यह असली Jio ODCPE Connect ऐप से reverse-engineer किया हुआ **सिर्फ़ ODU (AirFiber/5G outdoor unit) का BLE pairing + Bluetooth-tethering handshake** है।
**STB module इसमें शामिल नहीं है** — अलग protocol है, जैसा तय हुआ था।

## यह ऐप क्या करता है

1. आसपास के BLE devices scan करता है।
2. तुम्हारे चुने गए device से GATT connect करता है और service `0000ca77-...` ढूँढता है।
3. Characteristic `ca78` पर notifications enable करके, हर 100ms पर `0x01` byte भेजता है (heartbeat) — ठीक वैसे ही जैसे असली ऐप का `ESimBluetoothLeService` करता है।
4. Characteristic `ca7a` पर ODU के जवाब (PAN IP) का इंतज़ार करता है। 20 सेकंड में IP न मिले तो "BT tethering ON करो" वाला मैसेज दिखाता है।
5. एक बटन से सीधा Android की Bluetooth Tethering settings खोल देता है (`com.android.settings/.TetherSettings`), क्योंकि असली ऐप भी इसे खुद programmatically ON नहीं करता — manually करना पड़ता है।

**ज़रूरी:** यह protocol सिर्फ़ static code-reading से निकाला गया है, किसी असली ODU पर टेस्ट नहीं किया गया (मेरे पास device/BLE हार्डवेयर नहीं है)। तुम्हारे असली ODU पर पहली बार चलाने पर byte-level detail (जैसे heartbeat का exact payload, या notify बनाम read) में फ़र्क़ निकल सकता है — वो log screen में दिखेगा, मुझे बता देना तो ठीक कर दूँगा।

## Setup (अपने कंप्यूटर पर)

इस फ़ोल्डर में सिर्फ़ Dart code और `pubspec.yaml` है — Android/iOS का platform boilerplate तुम्हारे अपने Flutter version के हिसाब से generate होना चाहिए, इसलिए:

```bash
# 1. एक नया Flutter project बनाओ (असली platform files यहीं से आएँगे)
flutter create --org com.example odcpe_bt_tether_app
cd odcpe_bt_tether_app

# 2. मेरी दी हुई lib/ और pubspec.yaml इसमें कॉपी करो (overwrite करना है)
#    (dependencies लाइनों को अपने naya pubspec.yaml में merge करना न भूलना,
#     ya seedha mera pubspec.yaml hi copy kar do)

# 3. Dependencies लाओ
flutter pub get
```

फिर `android/app/src/main/AndroidManifest.xml` में `<manifest>` टैग के अंदर, `<application>` से पहले ये permissions जोड़ो:

```xml
<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-feature android:name="android.hardware.bluetooth_le" android:required="true" />
<queries>
    <package android:name="com.android.settings" />
</queries>
```

और `android/app/build.gradle` में `defaultConfig { }` के अंदर कम-से-कम:

```gradle
minSdkVersion 21
```

फिर फ़ोन USB से जोड़कर:

```bash
flutter run
```

## अगर कुछ काम न करे

- **Service ca77 न मिले** → scan की हुई list में सही ODU चुना है या नहीं, वो देखो। कुछ ODU models में service UUID थोड़ा अलग हो सकता है — उस हालत में nRF Connect (Play Store app) से ODU को scan करके असली UUIDs मुझे भेज देना, मैं कोड अपडेट कर दूँगा।
- **PAN IP कभी न आए** → पहले फ़ोन का Bluetooth Tethering ज़रूर ON करो (ऐप में बटन है), फिर दोबारा scan/connect करो।
- **Permission डिनाई हो** → Android Settings → Apps → इस ऐप में जाकर Location + Nearby devices permission manually ON करो।

## Files

- `lib/odu_protocol.dart` — पूरा BLE protocol logic (scan/connect अलग है, यह सिर्फ़ connect-के-बाद वाला handshake है)
- `lib/main.dart` — Scan screen + Connect/handshake screen (UI)
