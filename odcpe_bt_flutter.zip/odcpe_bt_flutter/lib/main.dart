import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:android_intent_plus/android_intent.dart';

import 'odu_protocol.dart';

void main() {
  runApp(const OduApp());
}

class OduApp extends StatelessWidget {
  const OduApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ODCPE BT Tether',
      theme: ThemeData(colorSchemeSeed: const Color(0xff23297a), useMaterial3: true),
      home: const ScanScreen(),
    );
  }
}

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final List<ScanResult> _results = [];
  bool _scanning = false;

  Future<void> _requestPermissions() async {
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
  }

  Future<void> _startScan() async {
    await _requestPermissions();
    setState(() {
      _results.clear();
      _scanning = true;
    });

    final sub = FlutterBluePlus.scanResults.listen((results) {
      setState(() {
        _results
          ..clear()
          ..addAll(results);
      });
    });

    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 12));
    await FlutterBluePlus.isScanning.where((v) => v == false).first;
    await sub.cancel();
    setState(() => _scanning = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ODCPE — Connect ODU')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: ElevatedButton.icon(
              onPressed: _scanning ? null : _startScan,
              icon: const Icon(Icons.bluetooth_searching),
              label: Text(_scanning ? 'Scanning...' : 'Scan for ODU'),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'अपने ODU (outdoor unit) को list में ढूँढो — नाम से पहचानना आसान न हो तो '
              'MAC address से मिलाओ, फिर उसपर टैप करो.',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          const Divider(),
          Expanded(
            child: ListView.builder(
              itemCount: _results.length,
              itemBuilder: (context, i) {
                final r = _results[i];
                final name = r.device.platformName.isNotEmpty ? r.device.platformName : '(no name)';
                return ListTile(
                  title: Text(name),
                  subtitle: Text('${r.device.remoteId}  •  RSSI ${r.rssi}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => ConnectScreen(device: r.device),
                    ));
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ConnectScreen extends StatefulWidget {
  final BluetoothDevice device;
  const ConnectScreen({super.key, required this.device});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  late final OduConnection _conn;
  OduStep _step = OduStep.idle;
  final List<String> _log = [];
  String? _panIp;

  @override
  void initState() {
    super.initState();
    _conn = OduConnection(widget.device);
    _conn.stepStream.listen((s) => setState(() => _step = s));
    _conn.logStream.listen((l) => setState(() => _log.add(l)));
    _conn.panIpStream.listen((ip) => setState(() => _panIp = ip));
    _conn.connectAndPair();
  }

  @override
  void dispose() {
    _conn.dispose();
    super.dispose();
  }

  Future<void> _openBtTetheringSettings() async {
    // Mirrors BLEConnectActivity: explicit intent to the system
    // Bluetooth-tethering screen; falls back to generic Bluetooth settings.
    try {
      final intent = AndroidIntent(
        action: 'android.intent.action.MAIN',
        package: 'com.android.settings',
        componentName: 'com.android.settings.TetherSettings',
      );
      await intent.launch();
    } catch (_) {
      final fallback = AndroidIntent(action: 'android.settings.BLUETOOTH_SETTINGS');
      await fallback.launch();
    }
  }

  String _stepLabel(OduStep s) {
    switch (s) {
      case OduStep.idle:
        return 'शुरू हो रहा है...';
      case OduStep.connecting:
        return 'ODU से GATT कनेक्ट हो रहा है...';
      case OduStep.discoveringServices:
        return 'Services ढूँढी जा रही हैं...';
      case OduStep.servicesNotFound:
        return 'ODU पर ज़रूरी BLE service नहीं मिली। ODU को reboot करके फिर कोशिश करो।';
      case OduStep.readWriteUnavailable:
        return 'Read/Write characteristics उपलब्ध नहीं। ODU और फ़ोन दोनों का Bluetooth बंद-चालू करो।';
      case OduStep.handshaking:
        return 'Handshake चल रहा है (heartbeat भेजा जा रहा है), PAN IP का इंतज़ार...';
      case OduStep.waitingForBtTethering:
        return '20 सेकंड में जवाब नहीं आया। अपने फ़ोन का Bluetooth Tethering ON करो और फिर से कोशिश करो।';
      case OduStep.deviceNotConnected:
        return 'ODU connected नहीं है। ODU को reboot करो।';
      case OduStep.success:
        return 'सफल! ODU tether होकर इंटरनेट से जुड़ गया।';
      case OduStep.gattDisconnected:
        return 'GATT disconnect हो गया।';
      case OduStep.error:
        return 'Error — नीचे log देखो।';
    }
  }

  @override
  Widget build(BuildContext context) {
    final name = widget.device.platformName.isNotEmpty ? widget.device.platformName : widget.device.remoteId.str;
    return Scaffold(
      appBar: AppBar(title: Text(name)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.bluetooth_connected),
                const SizedBox(width: 8),
                Expanded(child: Text(_stepLabel(_step), style: Theme.of(context).textTheme.titleMedium)),
              ],
            ),
            const SizedBox(height: 12),
            if (_panIp != null)
              Card(
                color: Colors.green.shade50,
                child: ListTile(
                  leading: const Icon(Icons.check_circle, color: Colors.green),
                  title: const Text('PAN IP (ODU से मिला)'),
                  subtitle: Text(_panIp!),
                ),
              ),
            if (_step == OduStep.waitingForBtTethering || _step == OduStep.deviceNotConnected)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: ElevatedButton.icon(
                  onPressed: _openBtTetheringSettings,
                  icon: const Icon(Icons.settings_bluetooth),
                  label: const Text('Bluetooth Tethering Settings खोलो'),
                ),
              ),
            const SizedBox(height: 12),
            const Text('Log:', style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: _log.length,
                itemBuilder: (context, i) => Text(_log[i], style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
