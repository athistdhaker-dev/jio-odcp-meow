import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_blue_plus/flutter_blue_plus.dart';

/// UUIDs reverse-engineered from the official ODCPE Connect app
/// (smali_classes2/xf/e.smali + ESimBluetoothLeService).
/// This file covers ONLY the ODU (AirFiber/5G outdoor unit) pairing +
/// Bluetooth-tethering handshake. The STB module is a separate, unrelated
/// flow and is intentionally not replicated here.
class OduUuids {
  static final service = Guid('0000ca77-0000-1000-a435-311b63657f1f');
  static final writeCommandChar = Guid('0000ca78-0000-1000-a435-311b63657f1f');
  static final unusedChar = Guid('0000ca79-0000-1000-a435-311b63657f1f'); // seen in app, never used
  static final panIpChar = Guid('0000ca7a-0000-1000-a435-311b63657f1f'); // ODU reports its tethering IP here
  static final resetBtCapabilityChar = Guid('0000ca7b-0000-1000-a435-311b63657f1f'); // presence-only flag
  static final cccd = Guid('00002902-0000-1000-8000-00805f9b34fb');
}

enum OduStep {
  idle,
  scanning,
  connecting,
  discoveringServices,
  servicesNotFound, // esim_step_2_1_ble_features_not_found
  readWriteUnavailable, // esim_step_2_2_bluetooth_read_write_failure
  handshaking, // heartbeat loop running, waiting for PAN IP
  waitingForBtTethering, // esim_step_4_2_bt_tethering_off equivalent
  deviceNotConnected, // esim_step_4_1_reboot_the_odu
  success, // got PAN IP
  gattDisconnected,
  error,
}

class OduConnection {
  final BluetoothDevice device;
  BluetoothCharacteristic? _writeChar;
  BluetoothCharacteristic? _panIpChar;
  bool resetBtAvailable = false;

  final _stepController = StreamController<OduStep>.broadcast();
  final _logController = StreamController<String>.broadcast();
  final _panIpController = StreamController<String>.broadcast();

  Stream<OduStep> get stepStream => _stepController.stream;
  Stream<String> get logStream => _logController.stream;
  Stream<String> get panIpStream => _panIpController.stream;

  Timer? _heartbeatTimer;
  Timer? _timeoutTimer;
  StreamSubscription<List<int>>? _panIpSub;
  StreamSubscription<BluetoothConnectionState>? _connSub;

  OduConnection(this.device);

  void _log(String msg) {
    // ignore: avoid_print
    print('[ODU] $msg');
    _logController.add(msg);
  }

  void _setStep(OduStep s) => _stepController.add(s);

  /// Full flow: connect -> discover services -> enable notifications ->
  /// start heartbeat -> wait up to 20s for the ODU to report its PAN IP.
  Future<void> connectAndPair() async {
    _setStep(OduStep.connecting);
    _log('Connecting to ${device.remoteId}...');

    _connSub = device.connectionState.listen((state) {
      if (state == BluetoothConnectionState.disconnected) {
        _log('GATT disconnected.');
        _setStep(OduStep.gattDisconnected);
        _cleanupTimers();
      }
    });

    try {
      await device.connect(timeout: const Duration(seconds: 15));
    } catch (e) {
      _log('Connect failed: $e');
      _setStep(OduStep.error);
      return;
    }

    _setStep(OduStep.discoveringServices);
    final services = await device.discoverServices();

    BluetoothService? oduService;
    for (final s in services) {
      if (s.uuid == OduUuids.service) {
        oduService = s;
        break;
      }
    }

    if (oduService == null) {
      _log('ODU GATT service (ca77) not found on this device.');
      _setStep(OduStep.servicesNotFound);
      return;
    }

    for (final c in oduService.characteristics) {
      if (c.uuid == OduUuids.writeCommandChar) _writeChar = c;
      if (c.uuid == OduUuids.panIpChar) _panIpChar = c;
      if (c.uuid == OduUuids.resetBtCapabilityChar) resetBtAvailable = true;
    }

    if (_writeChar == null || _panIpChar == null) {
      _log('Required characteristics (ca78/ca7a) missing.');
      _setStep(OduStep.readWriteUnavailable);
      return;
    }

    if (resetBtAvailable) {
      _log('ODU firmware supports BT-reset command (ca7b present).');
    }

    // Enable notifications on the PAN-IP characteristic.
    try {
      await _panIpChar!.setNotifyValue(true);
    } catch (e) {
      _log('Failed to enable notifications: $e');
      _setStep(OduStep.readWriteUnavailable);
      return;
    }

    _panIpSub = _panIpChar!.onValueReceived.listen(_onPanIpData);
    // Some firmwares answer a direct read instead of / as well as notify.
    unawaited(_panIpChar!.read().then(_onPanIpData).catchError((_) {}));

    _setStep(OduStep.handshaking);
    _log('Notifications enabled. Starting heartbeat, waiting for ODU PAN IP...');

    // Heartbeat: write 0x01 every 100ms, mirroring ESimBluetoothLeService.P().
    // IMPORTANT: the original app never calls setWriteType(WRITE_TYPE_NO_RESPONSE) —
    // it uses the characteristic's default write type, which on this ODU's ca78
    // characteristic is "write WITH response". withoutResponse:true throws
    // "WRITE_NO_RESPONSE property is not supported" on real hardware, so this
    // must stay false.
    bool heartbeatInFlight = false;
    _heartbeatTimer = Timer.periodic(const Duration(milliseconds: 100), (_) async {
      if (heartbeatInFlight || _writeChar == null) return;
      heartbeatInFlight = true;
      try {
        await _writeChar!.write(Uint8List.fromList([0x01]), withoutResponse: false);
      } catch (e) {
        _log('Heartbeat write failed: $e');
      } finally {
        heartbeatInFlight = false;
      }
    });

    // 20s timeout mirrors the official app's "device not connected" cutoff.
    _timeoutTimer = Timer(const Duration(seconds: 20), () {
      _log('No PAN IP after 20s — ODU likely not tethered / BT tethering off on phone.');
      _setStep(OduStep.waitingForBtTethering);
    });
  }

  void _onPanIpData(List<int> data) {
    if (data.isEmpty) return;
    final text = utf8.decode(data, allowMalformed: true).trim();
    if (text.length < 4) return; // mirrors the app's "valid IP length" check
    _log('ODU reported PAN IP: $text');
    _panIpController.add(text);
    _setStep(OduStep.success);
    _heartbeatTimer?.cancel();
    _timeoutTimer?.cancel();
  }

  void _cleanupTimers() {
    _heartbeatTimer?.cancel();
    _timeoutTimer?.cancel();
  }

  Future<void> dispose() async {
    _cleanupTimers();
    await _panIpSub?.cancel();
    await _connSub?.cancel();
    try {
      await device.disconnect();
    } catch (_) {}
    await _stepController.close();
    await _logController.close();
    await _panIpController.close();
  }
}
